DEBUG = True

MAINTENANCE_MODE = False

# DOMAIN_NAME = '127.0.0.1:8000'
# HTTP        = 'http'
# MODULE_NAME = 'ctm'
# DOMAIN_PATH = f'{HTTP}://{DOMAIN_NAME}/'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'ctm',
        'USER': 'postgres', 
        'PASSWORD': '123456', 
        'HOST': 'localhost', 
        'PORT': '5432', 
    },
}


# REDIS_CONFIG = {
#     'host': '127.0.0.1',
#     'port': 6379,
#     'db': 0,
#     'password': '',
#     'decode_responses': True
# }

CORS_ALLOW_CREDENTIALS = True
ALLOWED_HOSTS = ['*']
CORS_ALLOWED_ORIGINS = [
    'https://nargil.co',
    'https://api.nargil.co',
    'https://demo.nargil.co',
    'https://dev1.nargil.co',
    'https://dev2.nargil.co',
    'https://dev3.nargil.co',
    'https://dev4.nargil.co',
    'https://dev5.nargil.co',
    'http://localhost:4200',
]


DATE_TIME_PATTERN = '%Y-%m-%d %H:%M:%S'
DATE_PATTERN = '%Y-%m-%d'
